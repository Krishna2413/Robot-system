class Robot
  def initialize()
    # Initialize Variables to origin (0,0)
    # Direction N => Positive Y Axis, E => Positive X Axis, S=>Negative Y Axis, W => Negative X Axis
    @coord_x = 0
    @coord_y = 0
    @direction = 'N' # Assume that it is facing N i.e Positive Y Axis
  end

  def move(command)
    if command.length < 2
        puts "Invalid Arguments. Should be [F/B/L/R][NUM]."
        exit
    end
    command_type =  command[0]
    command_units =  command[1,command.length].to_i
    if !["F","B","L","R"].include?(command_type)
        puts "Invalid Command Type. Should be [F/B/L/R]."
        exit
    end
    if !command_units.is_a?(Numeric)
        puts "Invalid Units. Should be a Number."
        exit
    end
    if command_type == 'F'
        if @direction == 'N'
            @coord_y = @coord_y + command_units
        elsif @direction == 'E'
            @coord_x = @coord_x + command_units
        elsif @direction == 'W'
            @coord_x = @coord_x - command_units
        else
            @coord_y = @coord_y - command_units
        end
    elsif command_type == 'B'
        if @direction == 'N'
            @coord_y = @coord_y - command_units
        elsif @direction == 'E'
            @coord_x = @coord_x - command_units
        elsif @direction == 'W'
            @coord_x = @coord_x + command_units
        else
            @coord_y = @coord_y + command_units
        end
    elsif command_type == 'L' || command_type == 'R'
        effective_turns = command_units % 4
        turn(@direction,command_type,effective_turns)
    end
  end

  def turn(cur_direction, left_or_right, no_of_turns)
    directions_list = ['N','W','S','E']
    index_of_cur_direction = directions_list.index(cur_direction)
    if left_or_right == 'L'
        final_index = index_of_cur_direction + no_of_turns
        @direction = directions_list[final_index % 4 ]
    else
        final_index = index_of_cur_direction - no_of_turns
        if final_index < 0
            final_index = final_index + 4
        end
        @direction = directions_list[final_index % 4 ]
    end
  end

  def show_no_of_moves_required
    distance_x = @coord_x
    distance_y = @coord_y
    if distance_x < 0
        distance_x = distance_x * -1
    end
    if distance_y < 0
        distance_y = distance_y * -1
    end
    puts distance_x + distance_y
   end
end

if ARGV.length == 0
    puts "No directions provided. Usage `ruby Robot.rb F1 R2 ...`"
    exit
end

robot = Robot.new()

for arg in ARGV
   robot.move(arg)
end
robot.show_no_of_moves_required()
