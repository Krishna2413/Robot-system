 #  Woven Graduate CodingTest
 
 Usage : 
 
 ```
ruby src/Robot.rb [F/B/L/R<NUMBER>] 
```
  - Sample output
  
 ```bash
 ruby src/Robot.rb F1 R1 B2 L1 B3
 4
```

 ```bash
 ruby src/Robot.rb F6 L6 B1
 7
```
- Solved assuming the starting position as origin and each axis as a direction represented as N/E/W/S.
